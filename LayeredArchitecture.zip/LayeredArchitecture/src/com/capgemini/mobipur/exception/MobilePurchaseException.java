package com.capgemini.mobipur.exception;

public class MobilePurchaseException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 4473513424240627536L;

	public MobilePurchaseException()
	{
		
	}

	public MobilePurchaseException(String message) {
		super(message);
		
	}
}
