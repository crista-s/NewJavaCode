package com.capgemini.bank.exception;

public class ErrorException extends Exception {
	
	public ErrorException(String msg){
		super(msg);
	}
}
