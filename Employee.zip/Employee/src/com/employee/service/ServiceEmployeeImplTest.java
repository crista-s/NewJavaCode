package com.employee.service;

import static org.junit.Assert.assertTrue;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.employee.exception.EmployeeException;

public class ServiceEmployeeImplTest {

	private IServiceEmployee serviceEmployee;
	@Before
	public void setUp() throws Exception {
		
	}

	@After
	public void tearDown() throws Exception {
		
	}

	@Test
	public final void testUpdateEmployeeDetails() {
		
	}

}
